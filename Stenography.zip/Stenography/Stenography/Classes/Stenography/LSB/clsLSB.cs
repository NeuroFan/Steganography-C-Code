﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;

namespace Stenography.Classes.Stenography.LSB
{
   public class clsLSB
    {
        #region Variables
        Bitmap bmpMain;
        #endregion

        #region Functions
        //---------------------------------------------------------------
        public int[,] rndMatrix(int ImageWidth, int ImageHiegth, int seed)
        {
            int[,] rndMtx = new int[ImageWidth, ImageHiegth];
            Random rndint = new Random(seed);
            for (int i = 0; i < ImageWidth; i++)
            {
                for (int j = 0; j < ImageHiegth; j++)
                {
                    rndMtx[i, j] = rndint.Next(0, 2);
                }
            }

            for (int i = 0; i < 32; i++)
                rndMtx[0, i] = 1;

                return rndMtx;
        }

        //---------------------------------------------------
        public void Embed_Random(
            int[,] RandomMatrix,
            Bitmap bmp,
            byte[] btZip)
        {
            string strBins = clsConvertor.ConvertBytes2Bin(btZip);//data

            int lenStrBin = strBins.Length;

            string strDatalen = clsConvertor.ConvertInt2Bin(lenStrBin);//header of data

            string strAllBinData = strDatalen + strBins; //lenght of data

            lenStrBin = strAllBinData.Length;

            int Width = bmp.Size.Width,
                Height = bmp.Size.Height;

            byte Red, Green, Blue, data;

            Red = Green = Blue = 0;

            int indxBin = 0;

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    if (RandomMatrix[xR, yR] == 0) //Skip pixes whose are not chosen based on random pattern
                        continue;

                    Red = bmp.GetPixel(xR, yR).R;
                    Green = bmp.GetPixel(xR, yR).G;
                    Blue = bmp.GetPixel(xR, yR).B;

                    Red = ChangePixelValue(Red, strAllBinData[indxBin]);

                    Color cl = Color.FromArgb(Red, Green, Blue);

                    bmp.SetPixel(xR, yR, cl);

                    indxBin++;

                    if (indxBin == (13 * 8))
                    {

                    }

                    if (indxBin >= lenStrBin)
                        return; //isOutofData=true; 
                }

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    if (RandomMatrix[xR, yR] == 0) //Skip pixes whose are not chosen based on random pattern
                        continue;

                    Red = bmp.GetPixel(xR, yR).R;
                    Green = bmp.GetPixel(xR, yR).G;
                    Blue = bmp.GetPixel(xR, yR).B;

                    Green = ChangePixelValue(Green, strAllBinData[indxBin]);
                    //end control

                    Color cl = Color.FromArgb(Red, Green, Blue);

                    bmp.SetPixel(xR, yR, cl);

                    indxBin++;

                    if (indxBin > lenStrBin)
                        return; //isOutofData=true; 
                }

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    if (RandomMatrix[xR, yR] == 0) //Skip pixes whose are not chosen based on random pattern
                        continue;

                    Red = bmp.GetPixel(xR, yR).R;
                    Green = bmp.GetPixel(xR, yR).G;
                    Blue = bmp.GetPixel(xR, yR).B;

                    Blue = ChangePixelValue(Blue, strAllBinData[indxBin]);
                    //end control

                    Color cl = Color.FromArgb(Red, Green, Blue);

                    bmp.SetPixel(xR, yR, cl);

                    indxBin++;

                    if (indxBin > lenStrBin)
                        return; //isOutofData=true; 
                }
        }
        //---------------------------------------------------------------
        public static bool IsEven(int value)
        {
            return value % 2 == 0;
        }
        //---------------------------------------------------------------
        public static bool IsOdd(int value)
        {
            return value % 2 != 0;
        }
        //---------------------------------------------------------------
        public byte ChangePixelValue(byte PixCol,char Bit)
        {
            if (IsOdd(PixCol))
            {
                // if ((strAllBinData[indxBin] == '1'))
                // continue;//pixel=pixel;

                if ((Bit == '0'))
                    PixCol--;//pixel=pixel;
            }
            else//is even 
            {
                if ((Bit == '1'))
                    PixCol++;

                // if ((strAllBinData[indxBin] == '0'))
                //   ;//pixel=pixel;
            }
            return PixCol;
        }
        //---------------------------------------------------------------
        public void Embed(Bitmap bmp,byte[] btZip)
        {
            bool isOutofData = false;

            string strBins= clsConvertor.ConvertBytes2Bin(btZip);//data

            int lenStrBin = strBins.Length;
             
            string strDatalen = clsConvertor.ConvertInt2Bin(lenStrBin);//header of data

            //strBins = "";
            string strAllBinData = strDatalen + strBins; //lenght of data

            lenStrBin = strAllBinData.Length;

            int Width = bmp.Size.Width,                    
                Height = bmp.Size.Height;

            byte Red, Green, Blue,data;

            Red = Green = Blue=0;

            int indxBin = 0;

            for (int xR=0;xR<Width;xR++)
                for (int yR=0;yR<Height;yR++)
                {
                    Red = bmp.GetPixel(xR,yR).R;
                    Green = bmp.GetPixel(xR,yR).G;
                    Blue = bmp.GetPixel(xR,yR).B;

                    Red=ChangePixelValue(Red,strAllBinData[indxBin]);
                    //end control
                    //
                    Color cl = Color.FromArgb(Red,Green,Blue);

                    bmp.SetPixel(xR,yR,cl);

                    indxBin++;

                    if (indxBin==(13*8))
                    {

                    }

                        if (indxBin >= lenStrBin)
                        return; //isOutofData=true; 
                }

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    Red = bmp.GetPixel(xR, yR).R;
                    Green = bmp.GetPixel(xR, yR).G;
                    Blue = bmp.GetPixel(xR, yR).B;

                    Green = ChangePixelValue(Green, strAllBinData[indxBin]);
                    //end control

                    Color cl = Color.FromArgb(Red, Green, Blue);

                    bmp.SetPixel(xR, yR, cl);

                    indxBin++;

                    if (indxBin > lenStrBin)
                        return; //isOutofData=true; 
                }

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    Red = bmp.GetPixel(xR, yR).R;
                    Green = bmp.GetPixel(xR, yR).G;
                    Blue = bmp.GetPixel(xR, yR).B;

                    Blue = ChangePixelValue(Blue, strAllBinData[indxBin]);
                    //end control

                    Color cl = Color.FromArgb(Red, Green, Blue);

                    bmp.SetPixel(xR, yR, cl);

                    indxBin++;

                    if (indxBin > lenStrBin)
                        return; //isOutofData=true; 
                }
        }

        public string GetBitsImageRand(Bitmap bmp,int[,] matrand)
        {
            int Width = bmp.Width,
                Height = bmp.Height;

            String strAllData = string.Empty;

            byte Red, Green, Blue, data;

            string strDataLength = string.Empty;

            Red = Green = Blue = 0;
            //get the first 32 bit for len 
            for (int yR = 0; yR < 32; yR++)
            {
                Red = bmp.GetPixel(0, yR).R;

                if (IsOdd(Red))
                    strDataLength += '1';
                else
                    strDataLength += '0';
            }

            int ilenData = clsConvertor.ConvertBinString2int(strDataLength) + 32;

            int IndxBit = 0;

            strDataLength = string.Empty;

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    if (matrand[xR, yR] == 0) continue;

                    Red = bmp.GetPixel(xR, yR).R;

                    if (IsOdd(Red))
                        strAllData += '1';
                    else
                        strAllData += '0';

                    IndxBit++;
                    if (IndxBit >= ilenData)
                    {
                        //sss = strAllData.Length;
                        strAllData = strAllData.Substring(32);
                        // BinStringSpliter(strAllData);
                        return strAllData;
                    }
                }

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    if (matrand[xR, yR] == 0) continue;
                    Green = bmp.GetPixel(xR, yR).G;

                    if (IsOdd(Green))
                        strAllData += '1';
                    else
                        strAllData += '0';

                    IndxBit++;
                    if (IndxBit >= ilenData)
                    {
                        //sss = strAllData.Length;
                        strAllData = strAllData.Substring(32);
                        // BinStringSpliter(strAllData);
                        return strAllData;
                    }
                }

            //for section of header of data
            strAllData = strAllData.Substring(32);

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    if (matrand[xR, yR] == 0) continue;

                    Blue = bmp.GetPixel(xR, yR).B;

                    if (IsOdd(Blue))
                        strAllData += '1';
                    else
                        strAllData += '0';

                    IndxBit++;
                    if (IndxBit >= ilenData)
                    {
                        //sss = strAllData.Length;
                        //strAllData = strAllData.Substring(32);
                        // BinStringSpliter(strAllData);
                        return strAllData;
                    }
                }
            return strAllData;
        }
        //--------------------------------------------------------------
        public string GetBitsImage(Bitmap bmp)
        {
            int Width = bmp.Width,
                Height = bmp.Height;

            String strAllData = string.Empty;

            byte Red, Green, Blue, data;

            string strDataLength=string.Empty;

            Red = Green = Blue = 0;
            //get the first 32 bit for len 
            for (int yR = 0; yR < 32; yR++)
            {
                Red = bmp.GetPixel(0, yR).R;

                if (IsOdd(Red))
                    strDataLength += '1';
                else
                    strDataLength += '0';
            }

           int ilenData=clsConvertor.ConvertBinString2int(strDataLength)+32;

           int IndxBit = 0;

           strDataLength = string.Empty;

            for (int xR = 0; xR < Width; xR++)
                for (int yR =0; yR < Height; yR++)
                {
                    Red = bmp.GetPixel(xR, yR).R;

                    if (IsOdd(Red))
                        strAllData += '1';
                    else
                        strAllData += '0';

                    IndxBit++;
                    if (IndxBit >= ilenData)
                            {
                        //sss = strAllData.Length;
                        strAllData = strAllData.Substring(32);                      
                       // BinStringSpliter(strAllData);
                        return strAllData;
                    } 
                }
            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    Green = bmp.GetPixel(xR, yR).G;

                    if (IsOdd(Green))
                        strAllData += '1';
                    else
                        strAllData += '0';

                    IndxBit++;
                    if (IndxBit >= ilenData)
                    {
                        //sss = strAllData.Length;
                        strAllData = strAllData.Substring(32);
                        // BinStringSpliter(strAllData);
                        return strAllData;
                    }
                }

            //for section of header of data
            strAllData = strAllData.Substring(32);

            for (int xR = 0; xR < Width; xR++)
                for (int yR = 0; yR < Height; yR++)
                {
                    Blue = bmp.GetPixel(xR, yR).B;

                    if (IsOdd(Blue))
                        strAllData += '1';
                    else
                        strAllData += '0';

                    IndxBit++;
                    if (IndxBit >= ilenData)
                    {
                        //sss = strAllData.Length;
                        //strAllData = strAllData.Substring(32);
                        // BinStringSpliter(strAllData);
                        return strAllData;
                    }
                }
            return strAllData;
        }
        //---------------------------------------------------------------------
       public byte[] GetBinStringSpliter(string strBinData)
        {
            //create empty for adding data to 
            byte[] btData =new byte[(int)(strBinData.Length/8)];

            int indxStr = 0;

            for (int i = 0; i < strBinData.Length; i += 8)
            {
                //convert 8 bits to byte to save in binary file
                btData[indxStr] =
                    clsConvertor.ConvertBinString2Byte(strBinData.Substring(i, 8));
                if (i == (46 * 8))
                {
                }
                indxStr++;
            }
            //for (int indxStr = 0; indxStr < 135; indxStr++)
            //{
            //    btData[indxStr] =
            //        clsConvertor.ConvertBinString2Byte(strBinData.Substring(indxStr*8, 8));
            //    if (indxStr==46)
            //    {
            //    }
            //    //indxStr++;
            //}
            File.WriteAllBytes("E:\\Prg\\1.zip", btData);

            return btData;
        }
        //---------------------------------------------------------------------
        #endregion  

    }
}
