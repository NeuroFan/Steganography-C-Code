﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stenography
{
    class clsConvertor
    {
        //----------------------------------------------------------
        public static int ConvertBinString2int(string Strbin)
        {
            return Convert.ToInt32(Strbin, 2);
        }
        //----------------------------------------------------------
        public static byte ConvertBinString2Byte(string Strbin)
        {
            return Convert.ToByte(Strbin, 2);
        }
        //----------------------------------------------------------
        public static string ConvertInt2Bin(int ilenStr)
        {
            string strBin = Convert.ToString(ilenStr, 2);

            return strBin.PadLeft(32, '0');
        }

        public static string ConvertBytes2Bin(byte[] bt)
        {
            string strBin = string.Empty;
            byte btindx = 0;
            string strAllbin = string.Empty;

            if (bt!=null)
            for (int i = 0; i < bt.Length; i++)
            {
                btindx = bt[i];

                
                strBin = Convert.ToString(btindx, 2);
                strBin = strBin.PadLeft(8, '0');
                    if (i == 46)
                    {
                    }
                strAllbin += strBin;
            }

            return strAllbin;
        }
    }
}
