﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Compression;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Collections;
namespace Stenography.Classes.Control
{
    public class ClsZip
    {
        // string startPath;
        string zipPath;
        //-------------------------------------------------------------------------
        public void ZipFolder(string startPath, string zipPathpar)
        {
            try
            {
                zipPath = zipPathpar + "temp.zip";
                ZipFile.CreateFromDirectory(startPath, zipPath);
            }
            catch
            {
                ;
            }
 
        }
        //-------------------------------------------------------------------------
        public byte[] ZipFolderAndGetBytes(
            string startPath, string zipPathpar)
        {
            byte[] bt = null;

            try
            {
                zipPath = zipPathpar;
                ZipFolder(startPath,zipPath);
                bt=GetZipFileBytes();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                File.Delete(zipPath);
            }

            return bt;
        }
        //-------------------------------------------------------------------------
        public byte[] GetZipFileBytes()
        {
            return File.ReadAllBytes(zipPath);
        }
        //-------------------------------------------------------------------------
    
        //wetire

    }
}
