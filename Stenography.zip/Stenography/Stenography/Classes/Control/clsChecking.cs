﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stenography.Classes.Control
{
   public class clsChecking
    {
      
        public bool CompareSizeBitmapAndZipFile(Bitmap bmp,long fileSize)
        {
            long sizeBmp = (bmp.Width * bmp.Height);

            //rgb 
            long sizeBMPRGB = sizeBmp * 3;

            //if there is no space
            return (sizeBMPRGB < fileSize);
        }

       
    }
}
