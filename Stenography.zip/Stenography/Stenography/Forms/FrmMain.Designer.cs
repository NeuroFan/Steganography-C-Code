﻿namespace Stenography
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ribbonControl2 = new DevComponents.DotNetBar.RibbonControl();
            this.ribbonPanel3 = new DevComponents.DotNetBar.RibbonPanel();
            this.ribbonBar2 = new DevComponents.DotNetBar.RibbonBar();
            this.buttonItem12 = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar1 = new DevComponents.DotNetBar.RibbonBar();
            this.btnDatabaseManager = new DevComponents.DotNetBar.ButtonItem();
            this.btnUserManager = new DevComponents.DotNetBar.ButtonItem();
            this.btnEventLog = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem6 = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonPanel4 = new DevComponents.DotNetBar.RibbonPanel();
            this.PannelRotate = new DevComponents.DotNetBar.RibbonBar();
            this.btnGrpRotateLeft = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpRotateRight = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonBar6 = new DevComponents.DotNetBar.RibbonBar();
            this.btnGrpPanMode = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpZoomIn = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpZoomOut = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpZoomReset = new DevComponents.DotNetBar.ButtonItem();
            this.PanelGraphic = new DevComponents.DotNetBar.RibbonBar();
            this.btnGrpNewPage = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpOpenFile = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpGraphicSave = new DevComponents.DotNetBar.ButtonItem();
            this.btnGrpInvertColor = new DevComponents.DotNetBar.ButtonItem();
            this.ribSystemTools = new DevComponents.DotNetBar.RibbonTabItem();
            this.ribGraphics = new DevComponents.DotNetBar.RibbonTabItem();
            this.labelItem2 = new DevComponents.DotNetBar.LabelItem();
            this.buttonItem3 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem4 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem5 = new DevComponents.DotNetBar.ButtonItem();
            this.btnItmResetZoom = new DevComponents.DotNetBar.ButtonItem();
            this.labelItem1 = new DevComponents.DotNetBar.LabelItem();
            this.lbl_time = new DevComponents.DotNetBar.LabelItem();
            this.lbl_user = new DevComponents.DotNetBar.LabelItem();
            this.buttonFile = new DevComponents.DotNetBar.Office2007StartButton();
            this.itemContainer1 = new DevComponents.DotNetBar.ItemContainer();
            this.buttonItem11 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonExit = new DevComponents.DotNetBar.ButtonItem();
            this.buttonNew = new DevComponents.DotNetBar.ButtonItem();
            this.buttonSave = new DevComponents.DotNetBar.ButtonItem();
            this.buttonUndo = new DevComponents.DotNetBar.ButtonItem();
            this.ribbonTabItemGroup1 = new DevComponents.DotNetBar.RibbonTabItemGroup();
            this.btnShapes = new DevComponents.DotNetBar.ButtonItem();
            this.btnShapesLine = new DevComponents.DotNetBar.ButtonItem();
            this.btnShapesRectangle = new DevComponents.DotNetBar.ButtonItem();
            this.btnShapesCircle = new DevComponents.DotNetBar.ButtonItem();
            this.btnShapesText = new DevComponents.DotNetBar.ButtonItem();
            this.btnShapesImage = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraLine = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraRectangle = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraCircle = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraText = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraImage = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraLbs = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraCb = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraJumper = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraCutOutFuse = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraTransformer = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem1 = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem2 = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraHBridge = new DevComponents.DotNetBar.ButtonItem();
            this.btnDraVbridge = new DevComponents.DotNetBar.ButtonItem();
            this.btnReportBuilder = new DevComponents.DotNetBar.ButtonItem();
            this.buttonItem9 = new DevComponents.DotNetBar.ButtonItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picImage = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.ribbonControl2.SuspendLayout();
            this.ribbonPanel3.SuspendLayout();
            this.ribbonPanel4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl2
            // 
            this.ribbonControl2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            // 
            // 
            // 
            this.ribbonControl2.BackgroundStyle.Class = "";
            this.ribbonControl2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonControl2.CausesValidation = false;
            this.ribbonControl2.Controls.Add(this.ribbonPanel3);
            this.ribbonControl2.Controls.Add(this.ribbonPanel4);
            this.ribbonControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.ribbonControl2.EnableQatPlacement = false;
            this.ribbonControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbonControl2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.ribSystemTools,
            this.ribGraphics,
            this.labelItem2,
            this.buttonItem3,
            this.buttonItem4,
            this.buttonItem5,
            this.btnItmResetZoom,
            this.labelItem1,
            this.lbl_time,
            this.lbl_user});
            this.ribbonControl2.KeyTipsFont = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ribbonControl2.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl2.MdiSystemItemVisible = false;
            this.ribbonControl2.Name = "ribbonControl2";
            this.ribbonControl2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.ribbonControl2.QuickToolbarItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonFile,
            this.buttonNew,
            this.buttonSave,
            this.buttonUndo});
            this.ribbonControl2.Size = new System.Drawing.Size(1008, 103);
            this.ribbonControl2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonControl2.SystemText.MaximizeRibbonText = "&Maximize the Ribbon";
            this.ribbonControl2.SystemText.MinimizeRibbonText = "Mi&nimize the Ribbon";
            this.ribbonControl2.SystemText.QatAddItemText = "&Add to Quick Access Toolbar";
            this.ribbonControl2.SystemText.QatCustomizeMenuLabel = "<b>Customize Quick Access Toolbar</b>";
            this.ribbonControl2.SystemText.QatCustomizeText = "&Customize Quick Access Toolbar...";
            this.ribbonControl2.SystemText.QatDialogAddButton = "&Add >>";
            this.ribbonControl2.SystemText.QatDialogCancelButton = "Cancel";
            this.ribbonControl2.SystemText.QatDialogCaption = "Customize Quick Access Toolbar";
            this.ribbonControl2.SystemText.QatDialogCategoriesLabel = "&Choose commands from:";
            this.ribbonControl2.SystemText.QatDialogOkButton = "OK";
            this.ribbonControl2.SystemText.QatDialogPlacementCheckbox = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl2.SystemText.QatDialogRemoveButton = "&Remove";
            this.ribbonControl2.SystemText.QatPlaceAboveRibbonText = "&Place Quick Access Toolbar above the Ribbon";
            this.ribbonControl2.SystemText.QatPlaceBelowRibbonText = "&Place Quick Access Toolbar below the Ribbon";
            this.ribbonControl2.SystemText.QatRemoveItemText = "&Remove from Quick Access Toolbar";
            this.ribbonControl2.TabGroupHeight = 5;
            this.ribbonControl2.TabGroups.AddRange(new DevComponents.DotNetBar.RibbonTabItemGroup[] {
            this.ribbonTabItemGroup1});
            this.ribbonControl2.TabGroupsVisible = true;
            this.ribbonControl2.TabIndex = 13;
            // 
            // ribbonPanel3
            // 
            this.ribbonPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel3.Controls.Add(this.ribbonBar2);
            this.ribbonPanel3.Controls.Add(this.ribbonBar1);
            this.ribbonPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel3.Location = new System.Drawing.Point(0, 36);
            this.ribbonPanel3.Name = "ribbonPanel3";
            this.ribbonPanel3.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel3.Size = new System.Drawing.Size(1008, 65);
            // 
            // 
            // 
            this.ribbonPanel3.Style.Class = "";
            this.ribbonPanel3.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseDown.Class = "";
            this.ribbonPanel3.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel3.StyleMouseOver.Class = "";
            this.ribbonPanel3.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel3.TabIndex = 1;
            // 
            // ribbonBar2
            // 
            this.ribbonBar2.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar2.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.BackgroundStyle.Class = "";
            this.ribbonBar2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.ContainerControlProcessDialogKey = true;
            this.ribbonBar2.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar2.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.buttonItem12});
            this.ribbonBar2.Location = new System.Drawing.Point(241, 0);
            this.ribbonBar2.Name = "ribbonBar2";
            this.ribbonBar2.Size = new System.Drawing.Size(52, 62);
            this.ribbonBar2.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar2.TabIndex = 1;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyle.Class = "";
            this.ribbonBar2.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar2.TitleStyleMouseOver.Class = "";
            this.ribbonBar2.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar2.TitleVisible = false;
            // 
            // buttonItem12
            // 
            this.buttonItem12.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem12.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem12.Image")));
            this.buttonItem12.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem12.Name = "buttonItem12";
            this.buttonItem12.RibbonWordWrap = false;
            this.buttonItem12.Text = "Extract";
            this.buttonItem12.Click += new System.EventHandler(this.buttonItem12_Click);
            // 
            // ribbonBar1
            // 
            this.ribbonBar1.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar1.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.BackgroundStyle.Class = "";
            this.ribbonBar1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.ContainerControlProcessDialogKey = true;
            this.ribbonBar1.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnDatabaseManager,
            this.btnUserManager,
            this.btnEventLog,
            this.buttonItem6});
            this.ribbonBar1.Location = new System.Drawing.Point(3, 0);
            this.ribbonBar1.Name = "ribbonBar1";
            this.ribbonBar1.Size = new System.Drawing.Size(238, 62);
            this.ribbonBar1.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar1.TabIndex = 0;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyle.Class = "";
            this.ribbonBar1.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar1.TitleStyleMouseOver.Class = "";
            this.ribbonBar1.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar1.TitleVisible = false;
            // 
            // btnDatabaseManager
            // 
            this.btnDatabaseManager.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDatabaseManager.Image = ((System.Drawing.Image)(resources.GetObject("btnDatabaseManager.Image")));
            this.btnDatabaseManager.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDatabaseManager.Name = "btnDatabaseManager";
            this.btnDatabaseManager.RibbonWordWrap = false;
            this.btnDatabaseManager.Text = "Load Image";
            this.btnDatabaseManager.Click += new System.EventHandler(this.btnDatabaseManager_Click);
            // 
            // btnUserManager
            // 
            this.btnUserManager.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnUserManager.Image = ((System.Drawing.Image)(resources.GetObject("btnUserManager.Image")));
            this.btnUserManager.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnUserManager.Name = "btnUserManager";
            this.btnUserManager.RibbonWordWrap = false;
            this.btnUserManager.Text = "Select Folder";
            this.btnUserManager.Click += new System.EventHandler(this.btnUserManager_Click);
            // 
            // btnEventLog
            // 
            this.btnEventLog.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnEventLog.Image = ((System.Drawing.Image)(resources.GetObject("btnEventLog.Image")));
            this.btnEventLog.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnEventLog.Name = "btnEventLog";
            this.btnEventLog.RibbonWordWrap = false;
            this.btnEventLog.Text = "Embed";
            this.btnEventLog.Click += new System.EventHandler(this.btnEventLog_Click);
            // 
            // buttonItem6
            // 
            this.buttonItem6.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem6.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem6.Image")));
            this.buttonItem6.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem6.Name = "buttonItem6";
            this.buttonItem6.RibbonWordWrap = false;
            this.buttonItem6.Text = "Save";
            this.buttonItem6.Click += new System.EventHandler(this.buttonItem6_Click);
            // 
            // ribbonPanel4
            // 
            this.ribbonPanel4.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonPanel4.Controls.Add(this.PannelRotate);
            this.ribbonPanel4.Controls.Add(this.ribbonBar6);
            this.ribbonPanel4.Controls.Add(this.PanelGraphic);
            this.ribbonPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ribbonPanel4.Location = new System.Drawing.Point(0, 36);
            this.ribbonPanel4.Name = "ribbonPanel4";
            this.ribbonPanel4.Padding = new System.Windows.Forms.Padding(3, 0, 3, 3);
            this.ribbonPanel4.Size = new System.Drawing.Size(1008, 65);
            // 
            // 
            // 
            this.ribbonPanel4.Style.Class = "";
            this.ribbonPanel4.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseDown.Class = "";
            this.ribbonPanel4.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonPanel4.StyleMouseOver.Class = "";
            this.ribbonPanel4.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonPanel4.TabIndex = 4;
            this.ribbonPanel4.Visible = false;
            // 
            // PannelRotate
            // 
            this.PannelRotate.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.PannelRotate.BackgroundMouseOverStyle.Class = "";
            this.PannelRotate.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.PannelRotate.BackgroundStyle.Class = "";
            this.PannelRotate.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PannelRotate.ContainerControlProcessDialogKey = true;
            this.PannelRotate.Dock = System.Windows.Forms.DockStyle.Left;
            this.PannelRotate.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnGrpRotateLeft,
            this.btnGrpRotateRight});
            this.PannelRotate.Location = new System.Drawing.Point(471, 0);
            this.PannelRotate.Name = "PannelRotate";
            this.PannelRotate.Size = new System.Drawing.Size(145, 62);
            this.PannelRotate.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.PannelRotate.TabIndex = 18;
            // 
            // 
            // 
            this.PannelRotate.TitleStyle.Class = "";
            this.PannelRotate.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.PannelRotate.TitleStyleMouseOver.Class = "";
            this.PannelRotate.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PannelRotate.TitleVisible = false;
            // 
            // btnGrpRotateLeft
            // 
            this.btnGrpRotateLeft.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpRotateLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpRotateLeft.Image")));
            this.btnGrpRotateLeft.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpRotateLeft.Name = "btnGrpRotateLeft";
            this.btnGrpRotateLeft.RibbonWordWrap = false;
            this.btnGrpRotateLeft.Text = "Rotate Left";
            // 
            // btnGrpRotateRight
            // 
            this.btnGrpRotateRight.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpRotateRight.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpRotateRight.Image")));
            this.btnGrpRotateRight.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpRotateRight.Name = "btnGrpRotateRight";
            this.btnGrpRotateRight.RibbonWordWrap = false;
            this.btnGrpRotateRight.Text = "Rotate Right";
            // 
            // ribbonBar6
            // 
            this.ribbonBar6.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundMouseOverStyle.Class = "";
            this.ribbonBar6.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.BackgroundStyle.Class = "";
            this.ribbonBar6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar6.ContainerControlProcessDialogKey = true;
            this.ribbonBar6.Dock = System.Windows.Forms.DockStyle.Left;
            this.ribbonBar6.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnGrpPanMode,
            this.btnGrpZoomIn,
            this.btnGrpZoomOut,
            this.btnGrpZoomReset});
            this.ribbonBar6.Location = new System.Drawing.Point(232, 0);
            this.ribbonBar6.Name = "ribbonBar6";
            this.ribbonBar6.Size = new System.Drawing.Size(239, 62);
            this.ribbonBar6.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.ribbonBar6.TabIndex = 17;
            // 
            // 
            // 
            this.ribbonBar6.TitleStyle.Class = "";
            this.ribbonBar6.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.ribbonBar6.TitleStyleMouseOver.Class = "";
            this.ribbonBar6.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonBar6.TitleVisible = false;
            // 
            // btnGrpPanMode
            // 
            this.btnGrpPanMode.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpPanMode.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpPanMode.Image")));
            this.btnGrpPanMode.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpPanMode.Name = "btnGrpPanMode";
            this.btnGrpPanMode.RibbonWordWrap = false;
            this.btnGrpPanMode.Text = "Pan Mode";
            // 
            // btnGrpZoomIn
            // 
            this.btnGrpZoomIn.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpZoomIn.Image")));
            this.btnGrpZoomIn.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpZoomIn.Name = "btnGrpZoomIn";
            this.btnGrpZoomIn.RibbonWordWrap = false;
            this.btnGrpZoomIn.Text = "Zoom In";
            // 
            // btnGrpZoomOut
            // 
            this.btnGrpZoomOut.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpZoomOut.Image")));
            this.btnGrpZoomOut.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpZoomOut.Name = "btnGrpZoomOut";
            this.btnGrpZoomOut.RibbonWordWrap = false;
            this.btnGrpZoomOut.Text = "Zoom Out";
            // 
            // btnGrpZoomReset
            // 
            this.btnGrpZoomReset.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpZoomReset.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpZoomReset.Image")));
            this.btnGrpZoomReset.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpZoomReset.Name = "btnGrpZoomReset";
            this.btnGrpZoomReset.RibbonWordWrap = false;
            this.btnGrpZoomReset.Text = "Zoom Reset";
            // 
            // PanelGraphic
            // 
            this.PanelGraphic.AutoOverflowEnabled = true;
            // 
            // 
            // 
            this.PanelGraphic.BackgroundMouseOverStyle.Class = "";
            this.PanelGraphic.BackgroundMouseOverStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.PanelGraphic.BackgroundStyle.Class = "";
            this.PanelGraphic.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PanelGraphic.ContainerControlProcessDialogKey = true;
            this.PanelGraphic.Dock = System.Windows.Forms.DockStyle.Left;
            this.PanelGraphic.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnGrpNewPage,
            this.btnGrpOpenFile,
            this.btnGrpGraphicSave,
            this.btnGrpInvertColor});
            this.PanelGraphic.Location = new System.Drawing.Point(3, 0);
            this.PanelGraphic.Name = "PanelGraphic";
            this.PanelGraphic.Size = new System.Drawing.Size(229, 62);
            this.PanelGraphic.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.PanelGraphic.TabIndex = 1;
            // 
            // 
            // 
            this.PanelGraphic.TitleStyle.Class = "";
            this.PanelGraphic.TitleStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.PanelGraphic.TitleStyleMouseOver.Class = "";
            this.PanelGraphic.TitleStyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.PanelGraphic.TitleVisible = false;
            // 
            // btnGrpNewPage
            // 
            this.btnGrpNewPage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpNewPage.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpNewPage.Image")));
            this.btnGrpNewPage.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpNewPage.Name = "btnGrpNewPage";
            this.btnGrpNewPage.RibbonWordWrap = false;
            this.btnGrpNewPage.Text = "New Tab";
            this.btnGrpNewPage.Visible = false;
            // 
            // btnGrpOpenFile
            // 
            this.btnGrpOpenFile.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpOpenFile.Enabled = false;
            this.btnGrpOpenFile.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpOpenFile.Image")));
            this.btnGrpOpenFile.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpOpenFile.Name = "btnGrpOpenFile";
            this.btnGrpOpenFile.RibbonWordWrap = false;
            this.btnGrpOpenFile.Text = "Tab List";
            // 
            // btnGrpGraphicSave
            // 
            this.btnGrpGraphicSave.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpGraphicSave.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpGraphicSave.Image")));
            this.btnGrpGraphicSave.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpGraphicSave.Name = "btnGrpGraphicSave";
            this.btnGrpGraphicSave.RibbonWordWrap = false;
            this.btnGrpGraphicSave.Text = "Save";
            // 
            // btnGrpInvertColor
            // 
            this.btnGrpInvertColor.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnGrpInvertColor.Image = ((System.Drawing.Image)(resources.GetObject("btnGrpInvertColor.Image")));
            this.btnGrpInvertColor.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnGrpInvertColor.Name = "btnGrpInvertColor";
            this.btnGrpInvertColor.RibbonWordWrap = false;
            this.btnGrpInvertColor.Text = "Invert Color";
            // 
            // ribSystemTools
            // 
            this.ribSystemTools.Checked = true;
            this.ribSystemTools.Name = "ribSystemTools";
            this.ribSystemTools.Panel = this.ribbonPanel3;
            this.ribSystemTools.Text = "File";
            // 
            // ribGraphics
            // 
            this.ribGraphics.Name = "ribGraphics";
            this.ribGraphics.Panel = this.ribbonPanel4;
            this.ribGraphics.Text = "Graphics";
            // 
            // labelItem2
            // 
            this.labelItem2.Name = "labelItem2";
            this.labelItem2.Text = "           ";
            // 
            // buttonItem3
            // 
            this.buttonItem3.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem3.Image")));
            this.buttonItem3.Name = "buttonItem3";
            // 
            // buttonItem4
            // 
            this.buttonItem4.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem4.Image")));
            this.buttonItem4.Name = "buttonItem4";
            // 
            // buttonItem5
            // 
            this.buttonItem5.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem5.Image")));
            this.buttonItem5.Name = "buttonItem5";
            // 
            // btnItmResetZoom
            // 
            this.btnItmResetZoom.Image = ((System.Drawing.Image)(resources.GetObject("btnItmResetZoom.Image")));
            this.btnItmResetZoom.Name = "btnItmResetZoom";
            this.btnItmResetZoom.Text = "buttonItem8";
            // 
            // labelItem1
            // 
            this.labelItem1.Name = "labelItem1";
            this.labelItem1.Text = "                  ";
            // 
            // lbl_time
            // 
            this.lbl_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Text = "                                                                  ";
            // 
            // lbl_user
            // 
            this.lbl_user.Name = "lbl_user";
            // 
            // buttonFile
            // 
            this.buttonFile.AutoExpandOnClick = true;
            this.buttonFile.CanCustomize = false;
            this.buttonFile.HotTrackingStyle = DevComponents.DotNetBar.eHotTrackingStyle.Image;
            this.buttonFile.Image = ((System.Drawing.Image)(resources.GetObject("buttonFile.Image")));
            this.buttonFile.ImagePaddingHorizontal = 2;
            this.buttonFile.ImagePaddingVertical = 2;
            this.buttonFile.Name = "buttonFile";
            this.buttonFile.ShowSubItems = false;
            this.buttonFile.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itemContainer1,
            this.buttonItem11,
            this.buttonExit});
            this.buttonFile.Text = "&File";
            // 
            // itemContainer1
            // 
            // 
            // 
            // 
            this.itemContainer1.BackgroundStyle.Class = "";
            this.itemContainer1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.itemContainer1.Name = "itemContainer1";
            // 
            // buttonItem11
            // 
            this.buttonItem11.Name = "buttonItem11";
            this.buttonItem11.Text = "Minimize";
            // 
            // buttonExit
            // 
            this.buttonExit.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonExit.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.buttonExit.Image = ((System.Drawing.Image)(resources.GetObject("buttonExit.Image")));
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.SubItemsExpandWidth = 24;
            this.buttonExit.Text = "E&xit Program";
            // 
            // buttonNew
            // 
            this.buttonNew.Image = ((System.Drawing.Image)(resources.GetObject("buttonNew.Image")));
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Shortcuts.Add(DevComponents.DotNetBar.eShortcut.CtrlN);
            this.buttonNew.Text = "New Document";
            // 
            // buttonSave
            // 
            this.buttonSave.Enabled = false;
            this.buttonSave.Image = ((System.Drawing.Image)(resources.GetObject("buttonSave.Image")));
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Text = "buttonItem2";
            // 
            // buttonUndo
            // 
            this.buttonUndo.Enabled = false;
            this.buttonUndo.Image = ((System.Drawing.Image)(resources.GetObject("buttonUndo.Image")));
            this.buttonUndo.Name = "buttonUndo";
            this.buttonUndo.Text = "Undo";
            // 
            // ribbonTabItemGroup1
            // 
            this.ribbonTabItemGroup1.Color = DevComponents.DotNetBar.eRibbonTabGroupColor.Orange;
            this.ribbonTabItemGroup1.GroupTitle = "Tab Group";
            this.ribbonTabItemGroup1.Name = "ribbonTabItemGroup1";
            // 
            // 
            // 
            this.ribbonTabItemGroup1.Style.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(158)))), ((int)(((byte)(159)))));
            this.ribbonTabItemGroup1.Style.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(225)))), ((int)(((byte)(226)))));
            this.ribbonTabItemGroup1.Style.BackColorGradientAngle = 90;
            this.ribbonTabItemGroup1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.ribbonTabItemGroup1.Style.BorderBottomWidth = 1;
            this.ribbonTabItemGroup1.Style.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(58)))), ((int)(((byte)(59)))));
            this.ribbonTabItemGroup1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.ribbonTabItemGroup1.Style.BorderLeftWidth = 1;
            this.ribbonTabItemGroup1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.ribbonTabItemGroup1.Style.BorderRightWidth = 1;
            this.ribbonTabItemGroup1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.ribbonTabItemGroup1.Style.BorderTopWidth = 1;
            this.ribbonTabItemGroup1.Style.Class = "";
            this.ribbonTabItemGroup1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.ribbonTabItemGroup1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.ribbonTabItemGroup1.Style.TextColor = System.Drawing.Color.Black;
            this.ribbonTabItemGroup1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // btnShapes
            // 
            this.btnShapes.Image = ((System.Drawing.Image)(resources.GetObject("btnShapes.Image")));
            this.btnShapes.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnShapes.Name = "btnShapes";
            this.btnShapes.SplitButton = true;
            this.btnShapes.SubItems.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.btnShapesLine,
            this.btnShapesRectangle,
            this.btnShapesCircle,
            this.btnShapesText,
            this.btnShapesImage});
            this.btnShapes.Text = "Shapes";
            // 
            // btnShapesLine
            // 
            this.btnShapesLine.Image = ((System.Drawing.Image)(resources.GetObject("btnShapesLine.Image")));
            this.btnShapesLine.Name = "btnShapesLine";
            this.btnShapesLine.Text = "Line";
            // 
            // btnShapesRectangle
            // 
            this.btnShapesRectangle.Image = ((System.Drawing.Image)(resources.GetObject("btnShapesRectangle.Image")));
            this.btnShapesRectangle.Name = "btnShapesRectangle";
            this.btnShapesRectangle.Text = "Rectangle";
            // 
            // btnShapesCircle
            // 
            this.btnShapesCircle.Image = ((System.Drawing.Image)(resources.GetObject("btnShapesCircle.Image")));
            this.btnShapesCircle.Name = "btnShapesCircle";
            this.btnShapesCircle.Text = "Circle";
            // 
            // btnShapesText
            // 
            this.btnShapesText.Image = ((System.Drawing.Image)(resources.GetObject("btnShapesText.Image")));
            this.btnShapesText.Name = "btnShapesText";
            this.btnShapesText.Text = "Text";
            // 
            // btnShapesImage
            // 
            this.btnShapesImage.Image = ((System.Drawing.Image)(resources.GetObject("btnShapesImage.Image")));
            this.btnShapesImage.Name = "btnShapesImage";
            this.btnShapesImage.Text = "Image";
            // 
            // btnDraLine
            // 
            this.btnDraLine.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraLine.Image = ((System.Drawing.Image)(resources.GetObject("btnDraLine.Image")));
            this.btnDraLine.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraLine.Name = "btnDraLine";
            this.btnDraLine.RibbonWordWrap = false;
            this.btnDraLine.Text = "Line";
            // 
            // btnDraRectangle
            // 
            this.btnDraRectangle.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraRectangle.Image = ((System.Drawing.Image)(resources.GetObject("btnDraRectangle.Image")));
            this.btnDraRectangle.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraRectangle.Name = "btnDraRectangle";
            this.btnDraRectangle.RibbonWordWrap = false;
            this.btnDraRectangle.Text = "Rectangle";
            // 
            // btnDraCircle
            // 
            this.btnDraCircle.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraCircle.Image = ((System.Drawing.Image)(resources.GetObject("btnDraCircle.Image")));
            this.btnDraCircle.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraCircle.Name = "btnDraCircle";
            this.btnDraCircle.RibbonWordWrap = false;
            this.btnDraCircle.Text = "Circle";
            // 
            // btnDraText
            // 
            this.btnDraText.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraText.Image = ((System.Drawing.Image)(resources.GetObject("btnDraText.Image")));
            this.btnDraText.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraText.Name = "btnDraText";
            this.btnDraText.RibbonWordWrap = false;
            this.btnDraText.Text = "Text";
            // 
            // btnDraImage
            // 
            this.btnDraImage.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraImage.Image = ((System.Drawing.Image)(resources.GetObject("btnDraImage.Image")));
            this.btnDraImage.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraImage.Name = "btnDraImage";
            this.btnDraImage.RibbonWordWrap = false;
            this.btnDraImage.Text = "Image";
            // 
            // btnDraLbs
            // 
            this.btnDraLbs.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraLbs.Image = ((System.Drawing.Image)(resources.GetObject("btnDraLbs.Image")));
            this.btnDraLbs.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraLbs.Name = "btnDraLbs";
            this.btnDraLbs.RibbonWordWrap = false;
            this.btnDraLbs.Text = "LBS (Load Brask Switch) ";
            // 
            // btnDraCb
            // 
            this.btnDraCb.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraCb.Image = ((System.Drawing.Image)(resources.GetObject("btnDraCb.Image")));
            this.btnDraCb.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraCb.Name = "btnDraCb";
            this.btnDraCb.RibbonWordWrap = false;
            this.btnDraCb.Text = "CB (Circuit Breaker)";
            // 
            // btnDraJumper
            // 
            this.btnDraJumper.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraJumper.Image = ((System.Drawing.Image)(resources.GetObject("btnDraJumper.Image")));
            this.btnDraJumper.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraJumper.Name = "btnDraJumper";
            this.btnDraJumper.RibbonWordWrap = false;
            this.btnDraJumper.Text = "Jumper";
            // 
            // btnDraCutOutFuse
            // 
            this.btnDraCutOutFuse.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraCutOutFuse.Image = ((System.Drawing.Image)(resources.GetObject("btnDraCutOutFuse.Image")));
            this.btnDraCutOutFuse.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraCutOutFuse.Name = "btnDraCutOutFuse";
            this.btnDraCutOutFuse.RibbonWordWrap = false;
            this.btnDraCutOutFuse.Text = "Cut Out Fuse";
            // 
            // btnDraTransformer
            // 
            this.btnDraTransformer.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraTransformer.Image = ((System.Drawing.Image)(resources.GetObject("btnDraTransformer.Image")));
            this.btnDraTransformer.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraTransformer.Name = "btnDraTransformer";
            this.btnDraTransformer.RibbonWordWrap = false;
            this.btnDraTransformer.Text = "Transformer";
            // 
            // buttonItem1
            // 
            this.buttonItem1.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem1.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem1.Image")));
            this.buttonItem1.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem1.Name = "buttonItem1";
            this.buttonItem1.RibbonWordWrap = false;
            this.buttonItem1.Text = "Disconnector";
            // 
            // buttonItem2
            // 
            this.buttonItem2.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem2.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem2.Image")));
            this.buttonItem2.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem2.Name = "buttonItem2";
            this.buttonItem2.RibbonWordWrap = false;
            this.buttonItem2.Text = "Feeder";
            // 
            // btnDraHBridge
            // 
            this.btnDraHBridge.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraHBridge.Image = ((System.Drawing.Image)(resources.GetObject("btnDraHBridge.Image")));
            this.btnDraHBridge.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraHBridge.Name = "btnDraHBridge";
            this.btnDraHBridge.RibbonWordWrap = false;
            this.btnDraHBridge.Text = "Horizontal Bridge ";
            // 
            // btnDraVbridge
            // 
            this.btnDraVbridge.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnDraVbridge.Image = ((System.Drawing.Image)(resources.GetObject("btnDraVbridge.Image")));
            this.btnDraVbridge.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnDraVbridge.Name = "btnDraVbridge";
            this.btnDraVbridge.RibbonWordWrap = false;
            this.btnDraVbridge.Text = "Vertical Bridge";
            // 
            // btnReportBuilder
            // 
            this.btnReportBuilder.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.btnReportBuilder.Image = ((System.Drawing.Image)(resources.GetObject("btnReportBuilder.Image")));
            this.btnReportBuilder.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.btnReportBuilder.Name = "btnReportBuilder";
            this.btnReportBuilder.RibbonWordWrap = false;
            this.btnReportBuilder.Text = "Report Builder";
            // 
            // buttonItem9
            // 
            this.buttonItem9.ButtonStyle = DevComponents.DotNetBar.eButtonStyle.ImageAndText;
            this.buttonItem9.Image = ((System.Drawing.Image)(resources.GetObject("buttonItem9.Image")));
            this.buttonItem9.ImagePosition = DevComponents.DotNetBar.eImagePosition.Top;
            this.buttonItem9.Name = "buttonItem9";
            this.buttonItem9.RibbonWordWrap = false;
            this.buttonItem9.Text = "Device Diagram";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.picImage);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 103);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1008, 389);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Image";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(12, 316);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(220, 58);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Random Key";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(136, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Generate";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(47, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(83, 26);
            this.textBox1.TabIndex = 17;
            this.textBox1.Text = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Seed:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(801, 288);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Stego Image";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(468, 288);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Rand Image";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Cover Image";
            // 
            // picImage
            // 
            this.picImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picImage.Location = new System.Drawing.Point(12, 25);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(323, 255);
            this.picImage.TabIndex = 15;
            this.picImage.TabStop = false;
            this.picImage.Click += new System.EventHandler(this.picImage_Click_1);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Location = new System.Drawing.Point(673, 25);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(323, 255);
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Location = new System.Drawing.Point(343, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(323, 255);
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "*.jpeg)|*.jpeg|PNG Files (*.png)|*.png|JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|" +
    "*.gif";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 492);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ribbonControl2);
            this.DoubleBuffered = true;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Steganographer";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ribbonControl2.ResumeLayout(false);
            this.ribbonControl2.PerformLayout();
            this.ribbonPanel3.ResumeLayout(false);
            this.ribbonPanel4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevComponents.DotNetBar.RibbonControl ribbonControl2;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel3;
        private DevComponents.DotNetBar.RibbonBar ribbonBar1;
        private DevComponents.DotNetBar.ButtonItem btnDatabaseManager;
        private DevComponents.DotNetBar.ButtonItem btnUserManager;
        private DevComponents.DotNetBar.ButtonItem btnEventLog;
        private DevComponents.DotNetBar.ButtonItem buttonItem6;
        private DevComponents.DotNetBar.RibbonPanel ribbonPanel4;
        private DevComponents.DotNetBar.RibbonBar PannelRotate;
        private DevComponents.DotNetBar.ButtonItem btnGrpRotateLeft;
        private DevComponents.DotNetBar.ButtonItem btnGrpRotateRight;
        private DevComponents.DotNetBar.RibbonBar ribbonBar6;
        private DevComponents.DotNetBar.ButtonItem btnGrpPanMode;
        private DevComponents.DotNetBar.ButtonItem btnGrpZoomIn;
        private DevComponents.DotNetBar.ButtonItem btnGrpZoomOut;
        private DevComponents.DotNetBar.ButtonItem btnGrpZoomReset;
        private DevComponents.DotNetBar.RibbonBar PanelGraphic;
        private DevComponents.DotNetBar.ButtonItem btnGrpNewPage;
        private DevComponents.DotNetBar.ButtonItem btnGrpOpenFile;
        private DevComponents.DotNetBar.ButtonItem btnGrpGraphicSave;
        private DevComponents.DotNetBar.ButtonItem btnGrpInvertColor;
        private DevComponents.DotNetBar.RibbonTabItem ribSystemTools;
        private DevComponents.DotNetBar.RibbonTabItem ribGraphics;
        private DevComponents.DotNetBar.LabelItem labelItem2;
        private DevComponents.DotNetBar.ButtonItem buttonItem3;
        private DevComponents.DotNetBar.ButtonItem buttonItem4;
        private DevComponents.DotNetBar.ButtonItem buttonItem5;
        private DevComponents.DotNetBar.ButtonItem btnItmResetZoom;
        private DevComponents.DotNetBar.LabelItem labelItem1;
        private DevComponents.DotNetBar.LabelItem lbl_time;
        private DevComponents.DotNetBar.LabelItem lbl_user;
        private DevComponents.DotNetBar.Office2007StartButton buttonFile;
        private DevComponents.DotNetBar.ItemContainer itemContainer1;
        private DevComponents.DotNetBar.ButtonItem buttonItem11;
        private DevComponents.DotNetBar.ButtonItem buttonExit;
        private DevComponents.DotNetBar.ButtonItem buttonNew;
        private DevComponents.DotNetBar.ButtonItem buttonSave;
        private DevComponents.DotNetBar.ButtonItem buttonUndo;
        private DevComponents.DotNetBar.RibbonTabItemGroup ribbonTabItemGroup1;
        private DevComponents.DotNetBar.ButtonItem btnShapes;
        private DevComponents.DotNetBar.ButtonItem btnShapesLine;
        private DevComponents.DotNetBar.ButtonItem btnShapesRectangle;
        private DevComponents.DotNetBar.ButtonItem btnShapesCircle;
        private DevComponents.DotNetBar.ButtonItem btnShapesText;
        private DevComponents.DotNetBar.ButtonItem btnShapesImage;
        private DevComponents.DotNetBar.ButtonItem btnDraLine;
        private DevComponents.DotNetBar.ButtonItem btnDraRectangle;
        private DevComponents.DotNetBar.ButtonItem btnDraCircle;
        private DevComponents.DotNetBar.ButtonItem btnDraText;
        private DevComponents.DotNetBar.ButtonItem btnDraImage;
        private DevComponents.DotNetBar.ButtonItem btnDraLbs;
        private DevComponents.DotNetBar.ButtonItem btnDraCb;
        private DevComponents.DotNetBar.ButtonItem btnDraJumper;
        private DevComponents.DotNetBar.ButtonItem btnDraCutOutFuse;
        private DevComponents.DotNetBar.ButtonItem btnDraTransformer;
        private DevComponents.DotNetBar.ButtonItem buttonItem1;
        private DevComponents.DotNetBar.ButtonItem buttonItem2;
        private DevComponents.DotNetBar.ButtonItem btnDraHBridge;
        private DevComponents.DotNetBar.ButtonItem btnDraVbridge;
        private DevComponents.DotNetBar.ButtonItem btnReportBuilder;
        private DevComponents.DotNetBar.ButtonItem buttonItem9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox picImage;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button1;
        private DevComponents.DotNetBar.RibbonBar ribbonBar2;
        private DevComponents.DotNetBar.ButtonItem buttonItem12;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

