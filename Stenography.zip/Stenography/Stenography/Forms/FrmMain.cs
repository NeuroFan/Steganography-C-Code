﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using Stenography.Classes.Control;
using Stenography.Classes.Stenography.LSB;
using System.Diagnostics;

namespace Stenography
{
    public partial class Form1 : DevComponents.DotNetBar.Office2007Form
    {
        Bitmap imgCover,
              imgRand,
              imgStego;
        public static string strCurrenPath;

        string directoryPath = @"E:\Prg\1.txt";
        public static string zipPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) +"\\";
        public Form1()
        {
            InitializeComponent();
        }

        public static void CompressStringToFile(string fileName, string value)
        {
            // A.
            // Write string to temporary file.
            string temp = Path.GetTempFileName();
            File.WriteAllText(temp, value);

            // B.
            // Read file into byte array buffer.
            byte[] b;
            using (FileStream f = new FileStream(temp, FileMode.Open))
            {
                b = new byte[f.Length];
                f.Read(b, 0, (int)f.Length);
            }

            // C.
            // Use GZipStream to write compressed bytes to target file.
            using (FileStream f2 = new FileStream(fileName, FileMode.Create))
            using (GZipStream gz = new GZipStream(f2, CompressionMode.Compress, false))
            {
                gz.Write(b, 0, b.Length);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
             localhost.Service dd = new localhost.Service();
             string ss=   dd.is_on_network("fg");
            }
            catch(Exception ex)
            {

            }
            //ClsZip obj = new ClsZip();
            //byte[] bt=obj.ZipFolderAndGetBytes(@"E:\Prg\1", @"E:\Prg");

            //File.WriteAllBytes("E:\\Prg\\1.zip", bt);

            //clsLSB obj1 = new clsLSB();

            //Bitmap CoverImage=
            //    (Bitmap)Bitmap.FromFile(@"E:\Prg\1.png");

            //obj1.Embed(CoverImage, bt);

            //CoverImage.Save(@"E:\Prg\4.png",System.Drawing.Imaging.ImageFormat.Png);

            //string std= obj1.GetBitsImage((Bitmap)Bitmap.FromFile(@"E:\Prg\4.png"));

            //byte[] bt2 = obj1.GetBinStringSpliter(std);

            //byte[] bt3 = new byte[bt.Length];

            //for (byte i = 0; i < bt2.Length; i++)
            //    bt3[i] = (byte)(bt[i] - bt2[i]);

            //123
            //12

            // int it = 0;
            //string startPath = @"E:\Prg\1.txt";
            // string zipPath = @"E:\Prg\11.zip";

            // CompressStringToFile(startPath, "sdfsdfsdf");
            // ZipFile.CreateFromDirectory(startPath, zipPath);

            // ZipFile.ExtractToDirectory(zipPath, extractPath);

            // FileStream originalFileStream = File.Create("E:\\Prg\\11.zip");

            // FileStream ff = File.OpenWrite("E:\\Prg\\1.txt");

            // GZipStream compressionStream = new GZipStream(ff,
            //                    CompressionMode.Compress);

            // var fileStream = new FileStream("E:\\Prg\\11.zip", FileMode.Create, FileAccess.Write);

            // compressionStream.CopyTo(fileStream);

            //// compressionStream.
            // //originalFileStream.CopyTo(compressionStream);

            //originalFileStream.
        }

        private void picImage_Click(object sender, EventArgs e)
        {
            
        }

        private void picImage_Click_1(object sender, EventArgs e)
        {
            Forms.FrmShowImage frm = new Forms.FrmShowImage(picImage.Image);
            frm.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Forms.FrmShowImage frm = new Forms.FrmShowImage(pictureBox2.Image);
            frm.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Forms.FrmShowImage frm = new Forms.FrmShowImage(pictureBox3.Image);
            frm.Show();
        }

        void CreateRandImage(int [,] randMtx)
        {
            imgRand = new Bitmap(imgCover.Width,imgCover.Height);
            byte Cl;
            Color Colour;
            for (int i=0;i< imgCover.Width;i++)
            {
                for (int j=0;j< imgCover.Height;j++)
                   {
                    Cl = (byte)(255 * randMtx[i, j]);
                    Colour = Color.FromArgb(Cl, Cl, Cl);
                    imgRand.SetPixel(i, j, Colour); 
                   }
            }
        }

        int[,] matRand;

        private void btnDatabaseManager_Click(object sender, EventArgs e)
        {
            DialogResult dg = openFileDialog1.ShowDialog();

            if (dg==DialogResult.OK)
            {
               imgCover= 
                    (Bitmap)Image.FromFile(openFileDialog1.FileName);

                picImage.Image = imgCover;

                clsLSB obj = new clsLSB();

                matRand = obj.rndMatrix(imgCover.Width, imgCover.Height, int.Parse(textBox1.Text));
                CreateRandImage(matRand);
                pictureBox2.Image = imgRand;
                //drgdrg
            }

          

        }

        string folderPath = string.Empty;

        int GetSumRandMatrix()
        {
            int isum = 0;

            for (int i = 0; i < imgCover.Width; i++)
                for (int j = 0; j < imgCover.Height; j++)
                {
                    isum += matRand[i,j];
                }

            return isum;
        }

        private void StartProcess(string path)
        {
            try
            { 
            //StartInformation.FileName = path;

            //    Process procestry {
            //    ProcessStartInfo StartInformation = new ProcessStartInfo();

            //    StartInfis = Process.Start(StartInformation);

             //   process.EnableRasingEvents = true;
            }
            catch
            {

            }
        }

        private void buttonItem12_Click(object sender, EventArgs e)
        {
            try
            {

                DialogResult dg1 = openFileDialog1.ShowDialog();
                if (dg1==DialogResult.OK)
                {
                    imgStego =(Bitmap)Image.FromFile(openFileDialog1.FileName);

                    clsLSB obj = new clsLSB();

                    matRand = obj.rndMatrix(imgStego.Width, imgStego.Height, int.Parse(textBox1.Text));

                    String str = obj.GetBitsImageRand(imgStego, matRand);

                    byte[] bt2 = obj.GetBinStringSpliter(str);

                    DialogResult dg = folderBrowserDialog1.ShowDialog();

                    if (dg == DialogResult.OK)
                    {
                        //---------------
                        string strFileZip = strCurrenPath + "\\1.zip";

                        File.WriteAllBytes(
                             strFileZip
                            , bt2);

                        ZipFile.ExtractToDirectory(
                            strFileZip,
                            folderBrowserDialog1.SelectedPath);

                        StartProcess(folderBrowserDialog1.SelectedPath);

                        File.Delete(strFileZip);
                    }
                }

                

           
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonItem6_Click(object sender, EventArgs e)
        {
            DialogResult dg=saveFileDialog1.ShowDialog();

            if (dg == DialogResult.OK)
            {
                imgStego.Save(saveFileDialog1.FileName);
            }
        }

        //----------------------------------------------------------

        private void btnUserManager_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dg = folderBrowserDialog1.ShowDialog();

                if (dg == DialogResult.OK)
                {
                    folderPath = folderBrowserDialog1.SelectedPath;

                



                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //----------------------------------------------------------
        private void btnEventLog_Click(object sender, EventArgs e)
        {
            clsLSB obj = new clsLSB();

            ClsZip objzip = new ClsZip();

            byte[] bt =
                objzip.ZipFolderAndGetBytes(
                folderPath,
                folderPath);

            //checking
            int lenBytes = bt.Length * 8;

            int lenCoverImage = 3 * GetSumRandMatrix();

            if (lenBytes > lenCoverImage)
            {
                MessageBox.Show("Data Size Too Big for This Image");
                return;
            }

            imgStego = (Bitmap)imgCover.Clone();

            obj.Embed_Random(matRand, imgStego, bt);

            pictureBox3.Image = imgStego;
        }
        //----------------------------------------------------------
        //public static void Compress(DirectoryInfo directorySelected)
        //{
        //    foreach (FileInfo fileToCompress in directorySelected.GetFiles())
        //    {
        //        using (FileStream originalFileStream = fileToCompress.OpenRead())
        //        {
        //            if ((File.GetAttributes(fileToCompress.FullName) &
        //               FileAttributes.Hidden) != FileAttributes.Hidden & fileToCompress.Extension != ".gz")
        //            {
        //                using (FileStream compressedFileStream = File.Create(fileToCompress.FullName + ".gz"))
        //                {
        //                    using (GZipStream compressionStream = new GZipStream(compressedFileStream,
        //                       CompressionMode.Compress))
        //                    {
        //                        originalFileStream.CopyTo(compressionStream);

        //                    }
        //                }
        //                FileInfo info = new FileInfo(directoryPath + "\\" + fileToCompress.Name + ".gz");
        //                Console.WriteLine("Compressed {0} from {1} to {2} bytes.",
        //                fileToCompress.Name, fileToCompress.Length.ToString(), info.Length.ToString());
        //            }

        //        }
        //    }
        //}

        //public static void Decompress(FileInfo fileToDecompress)
        //{
        //    using (FileStream originalFileStream = fileToDecompress.OpenRead())
        //    {
        //        string currentFileName = fileToDecompress.FullName;
        //        string newFileName = currentFileName.Remove(currentFileName.Length - fileToDecompress.Extension.Length);

        //        using (FileStream decompressedFileStream = File.Create(newFileName))
        //        {
        //            using (GZipStream decompressionStream = new GZipStream(originalFileStream, CompressionMode.Decompress))
        //            {
        //                decompressionStream.CopyTo(decompressedFileStream);
        //                Console.WriteLine("Decompressed: {0}", fileToDecompress.Name);
        //            }
        //        }
        //    }
        //}
    }
}
